<div class="content">
  <div class="row">
    <div class="col-md-12">
      <?php $this->view('backend/kategori/tabel', ['kategori' => $kategori]) ?>
    </div>
  </div>
</div>
