<div class="content">

  <div class="row">
    <div class="col-md-8">
      <?php $this->view('backend/kategori/tabel', ['kategori' => $kategori]) ?>
    </div>
    <div class="col-md-4">
      <?php $this->view('backend/kategori/form') ?>
    </div>
  </div>
</div>
