<?php echo "<pre>".print_r($data, 1).'</pre>'; ?>
